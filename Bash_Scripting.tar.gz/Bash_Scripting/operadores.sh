

#!/bin/bash
NUM1=10
NUM2=5






RESULTADO=`expr $NUM1 /  $NUM2` 




echo "$NUM1 /  $NUM2 = $RESULTADO"


exit 0


