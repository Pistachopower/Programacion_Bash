#!/bin/bash 

if [ -d /home/nelson/Escritorio/CARPETA ];then
	echo "Es un directorio"
else 
	echo "Es un archivo"
fi
exit 0
