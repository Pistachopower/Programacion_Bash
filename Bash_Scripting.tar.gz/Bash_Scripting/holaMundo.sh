#!/bin/bash
#Mi primer programa en bash script






echo "Hola mundo"




#salida del programa













