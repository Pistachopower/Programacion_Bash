#!/bin/bash 

NUM1=5
NUM2=3

#Recuerda que la mayoria de los errores 
#vienen por los espacios de la concatenacion  
#de la variable

RESULTADO=$((NUM1 + NUM2))

echo "El resultado de la suma es: $RESULTADO"
