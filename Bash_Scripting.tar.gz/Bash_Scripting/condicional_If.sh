#!/bin/bash

#-f: si es un archivo
#-d: si es un directorio





if [ -f /home/nelson/Escritorio/migracion ];then
	echo "Es un archivo" 
else
	echo "Es un directorio "
fi

exit 0







 





  
