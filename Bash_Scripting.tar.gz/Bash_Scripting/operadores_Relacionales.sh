#!/bin/bash
NUM1=20

NUM2=10


#-eq: igual a 
#-le: menor que





if [ "$NUM1" -le "$NUM2" ];then
	echo "20 es mayor que 10"
else
	echo "10 es mayor que 20" 
fi

exit 0	


