#!/bin/bash 

echo "Hola. Introduce tu nombre: "
read  nombre

echo "Tu nombre es $nombre"
