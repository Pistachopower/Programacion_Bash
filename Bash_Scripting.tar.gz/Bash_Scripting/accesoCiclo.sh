#!/bin/bash 

#usamos clear para limpiar la pantalla  antes de ejecutar el programa
clear
: '
Algoritmo que nos diga si una persona puede acceder a cursar un ciclo formativo de 
grado superior o no. Podrá acceder a un grado superior si se tiene un titulo de bachiller, 
en caso de no tenerlo, se puede acceder si hemos superado una prueba de acceso.
'


echo "¿Tienes título de bachiller? "
read respuesta

if [ "$respuesta" = "f" ];then
        echo "¿Has superado la prueba de acceso? "
        read respuesta

        if [ "$respuesta" = "v" ];then
                echo "Puedes entrar al ciclo"
        else
                echo "NO puedes hacer el ciclo "
        fi

else
        echo "Puedes entrar al ciclo"
fi






